
# Unified Streamlit Project

This project integrates multiple Streamlit applications into a single interface. 
Users can select and run any of the following apps from the sidebar:

- Life Coach
- Ethical Dilemma System
- School Food
- Literature
- Grasps
- Test Feedback
- Student Record Enhancement System
- Curriculum
- Evaluation

## Structure

- `app.py`: The main entry point for the unified Streamlit app.
- `apps/`: Contains individual app modules.
- `requirements.txt`: Python dependencies for the project.

## Running the App

To run the unified Streamlit app, use the following command:

```bash
streamlit run app.py
```

Make sure to install the required dependencies first:

```bash
pip install -r requirements.txt
```
